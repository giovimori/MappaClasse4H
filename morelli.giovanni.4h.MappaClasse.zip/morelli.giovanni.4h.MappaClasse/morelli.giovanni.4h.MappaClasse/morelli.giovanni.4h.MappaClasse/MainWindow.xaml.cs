﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace morelli.giovanni._4h.MappaClasse
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button_click_1(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("In questo banco è presente: " + "Pompa Paolo");
            btn1.Content = "Pompa Paolo";
        }
        private void button_click_2(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("In questo banco è presente: " + "Salvi Matteo");
            btn2.Content = "Salvi Matteo";
        }
        private void button_click_3(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("In questo banco è presente: " + "Lomabrdi Samuele");
            btn3.Content = "Lomabrdi Samuele";
        }
        private void button_click_4(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("In questo banco è presente: " + "Cau Federico");
            btn4.Content = "Cau Federico";
        }
        private void button_click_5(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("In questo banco è presente: " + "Capanna Alessandro");
            btn5.Content = "Capanna Alessandro";
        }
        private void button_click_6(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("In questo banco è presente: " + "Islamovsky Fatih");
            btn6.Content = "Islamovsky Fatih";
        }
        private void button_click_7(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("In questo banco sono presenti: " + "Capicchioni D. e Zhang F.");
            btn7.Content = "Capicchioni D. e Zhang F.";
        }
        private void button_click_8(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("In questo banco è presente: " + "Morelli Giovanni");
            btn8.Content = "Morelli Giovanni";
        }
        private void button_click_9(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("In questo banco è presente: " + "Casadei Federico");
            btn9.Content = "Casadei Federico";
        }
        private void button_click_10(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("In questo banco è presente: " + "Burioli Alessandro");
            btn10.Content = "Burioli Alessandro";
        }
        private void button_click_11(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("In questo banco è presente: " + "Dervishi Samuele");
            btn11.Content = "Dervishi Samuele";
        }
        private void button_click_12(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("In questo banco è presente: " + "Basilico Karol");
            btn12.Content = "Basilico Karol";
        }
        private void button_click_13(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("In questo banco sono presenti: " + "Tumidei M. e Cancellieri A.");
            btn13.Content = "Tumidei M. e Cancellieri A.";
        }
        private void button_click_14(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("In questo banco è presente: " + "Rossini Agostino");
            btn14.Content = "Rossini Agostino";
        }
        private void button_click_15(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("In questo banco è presente: " + "Priori Francesco");
            btn15.Content = "Priori Francesco";
        }
        private void button_click_16(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("In questo banco sono presenti: " + "Chietti A. e Dyrmyshi L.");
            btn16.Content = "Chietti A. e Dyrmyshi L.";
        }
        
         private void button_click_17(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Postazione per PC portatile");
            btn17.Content = "Vuoto";
        }
        
      private void button_click_18(object sender, RoutedEventArgs e)
        {
          MessageBox.Show("Postazione per PC portatile occupata da: " + "Ghinelli Valentino");
          btn18.Content = "Ghinelli Valentino";
      }
      private void button_click_19(object sender, RoutedEventArgs e)
      {
          MessageBox.Show("Postazione per PC portatile occupata da: " + "Ricci Joseph");
          btn19.Content = "Ricci Joseph";
      }
      private void button_click_20(object sender, RoutedEventArgs e)
      {
          MessageBox.Show("Postazione per PC portatile"); 
          btn20.Content = "Vuoto";

      }
        private void button_click_21(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Postazione per PC portatile");
            btn21.Content = "Vuoto";

        }
        private void button_click_22(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Cattedra");
            

        }

    }
}
